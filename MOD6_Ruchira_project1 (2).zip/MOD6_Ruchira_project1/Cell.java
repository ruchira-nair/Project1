
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A cell in a 2D cellular automaton. The cell has multiple possible states.
 * This is an implementation of the rules for scalp
 * 
 * @ruchira
 * @9/21
 */
public class Cell
{
    // The possible states.
    public static final int Healthy = 0, Spread = 1, Spreading = 2;
    // The number of possible states.
    public static final int NUM_STATES = 3;

    // The cell's state.
    private int state;
    // The cell's neighbors.
    private Cell[] neighbors;

    /**
     * Set the initial state to be Spread.
     */
    public Cell()
    {
        this(Healthy);
    }
    
    /**
     * Set the initial state.
     * @param initialState The initial state
     */
    public Cell(int initialState)
    {
        state = initialState;
        neighbors = new Cell[1];
    }
    
    /**
     * Determine this cell's next state, based on the state of its neighbors.
     * This is an implementation of the rules for Brian's Brain.
     * @return The next state.
     */
  public int getNextState() { 
      int healthyCount = 0; int spreadCount = 0; int spreadingCount = 0; 
      // Count the different types of neighbors.
      for(Cell neighbor : neighbors) 
      { if(neighbor.getState() == Healthy) 
          { healthyCount++; }
          else if(neighbor.getState() == Spread)
          { spreadCount++; }
          else if(neighbor.getState() == Spreading)
          { spreadingCount++; } } 
          // Rules for a Healthy cell. 
          if(state == Healthy) 
          { if(spreadCount >= 1 || spreadingCount >= 2)
              { return Spreading; } 
              return Healthy; } 
              // Rules for a Spreading cell. 
              else if(state == Spreading) 
              { if(spreadCount >= 1)
                  { return Spread; } 
                  return Spreading; } 
                  // Rules for a Spread cell.
                  else { if(healthyCount >= 3) 
                      { return Healthy; } 
                      else if(healthyCount >= 2) 
                      { return Spreading; } 
                      return Spread; } }
    
    /**
     * Receive the list of neighboring cells and take a copy.
     * @param neighborList Neighboring cells.
     */
    public void setNeighbors(ArrayList<Cell> neighborList)
    {
        neighbors = neighborList.toArray(new Cell[0]);
    }

    /**
     * Get the state of this cell.
     * @return The state.
     */
    public int getState()
    {
        return state;
    }
    
    /**
     * Set the state of this cell.
     * @param The state.
     */
    public void setState(int state)
    {
        this.state = state;
    }
}
