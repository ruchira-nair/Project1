import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
/**
 * Write a description of class RatioGraph here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
 

public class RatioGraph
{
    private ArrayList<Double> history;
    private JFrame frame;

    public RatioGraph(ArrayList<Double> history)
    {
        this.history = history;

        frame = new JFrame("Healthy : Spread Ratio");
        frame.setSize(500, 400);
        frame.setVisible(true);
    }

    public void updateHistory(ArrayList<Double> history)
    {
        this.history = history;
        frame.repaint();
    }

 
    public void repaint()
        {
        Graphics graphics = frame.getGraphics();
    
        if(graphics != null) {
        draw(graphics, frame.getContentPane().getWidth(),
             frame.getContentPane().getHeight());
        graphics.dispose();
        }
    }

    private void draw(Graphics graphics, int width, int height)
    {
        int left = 50;
        int right = width - 25;
        int top = 40;
        int bottom = height - 45;

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);

        graphics.setColor(Color.BLACK);

        graphics.drawString(
            "Healthy : Spread Ratio",
            150,
            20
        );

        graphics.drawLine(left, top, left, bottom);
        graphics.drawLine(left, bottom, right, bottom);

        graphics.drawString("Ratio", 10, top);
        graphics.drawString("Time (steps)", right - 80, bottom + 30);

        if(history.size() == 0) {
            graphics.drawString("Press Step or Run", 170, 150);
            return;
        }

        double maxRatio = 1.0;

        for(Double ratio : history) {
            if(!ratio.isNaN() && ratio > maxRatio) {
                maxRatio = ratio;
            }
        }

        maxRatio = maxRatio * 1.1;

        int maxSteps = history.size();

        int previousX = -1;
        int previousY = -1;

        graphics.setColor(Color.RED);

        for(int i = 0; i < history.size(); i++) {

            double ratio = history.get(i);

            if(Double.isNaN(ratio)) {
                previousX = -1;
                previousY = -1;
                continue;
            }

            int x;

            if(maxSteps == 1) {
                x = left;
            }
            else {
                x = left +
                    (i * (right - left))
                    / (maxSteps - 1);
            }

            int y = bottom -
                (int)((ratio / maxRatio) *
                (bottom - top));

            if(previousX != -1) {
                graphics.drawLine(
                    previousX,
                    previousY,
                    x,
                    y
                );
            }

            graphics.fillOval(x - 3, y - 3, 6, 6);

            previousX = x;
            previousY = y;
        }

        graphics.setColor(Color.BLACK);

        graphics.drawString(
            String.format("%.2f", maxRatio),
            5,
            top + 5
        );

        graphics.drawString(
            String.format("%.2f", maxRatio / 2),
            5,
            (top + bottom) / 2
        );

        graphics.drawString("0", 20, bottom + 5);
        graphics.drawString("0", left - 5, bottom + 15);
        graphics.drawString(
            String.valueOf(maxSteps),
            right - 10,
            bottom + 15
        );
    }
}