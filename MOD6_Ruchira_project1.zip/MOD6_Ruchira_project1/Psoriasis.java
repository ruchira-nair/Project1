import java.security.SecureRandom;
import java.util.*;
import javax.swing.*;
import java.awt.*;

/**
 * A cell condition in a 2D cellular automaton. The cell has multiple possible states.
 * This is an implementation of the rules for condition
 * 
 * @ruchira
 * @10/9/26
 * 
 * sources - https://www.w3schools.com/java/, blueJ sixth edition, blueJ chapter 7 brain assignment, YouTube, & https://docs.oracle.com/en/java/javase/22/
 */ 
public class Psoriasis
{
    
    // The grid of cells.
    private Cell[][] cells;
    // Visualization of the environment.
    private final PsoriasisView view;
    private int stepCount = 0;
    private ArrayList<Double> ratioHistory = new ArrayList<Double>();
    /** 
     * Create an environment with the given size.
     * @param numRows The number of rows.
     * @param numCols The number of cols;
     */
    public Psoriasis(int numRows, int numCols)
    {
        setup(numRows, numCols);
        randomize();
        view = new PsoriasisView(this, numRows, numCols);
        view.showCells();
    }
    
    public static void main(String[] args)
    {
    int rows;
    int cols;

    try {
        String rowInput = JOptionPane.showInputDialog(
            null, "Enter the number of rows:");

        if(rowInput == null) {
            showErrorAndExit("Error: Input was cancelled.");
            return;
        }

        String colInput = JOptionPane.showInputDialog(
            null, "Enter the number of columns:");

        if(colInput == null) {
            showErrorAndExit("Error: Input was cancelled.");
            return;
        }

        rows = Integer.parseInt(rowInput);
        cols = Integer.parseInt(colInput);

        if(rows <= 0 || cols <= 0) {
            showErrorAndExit(
                "Error: Rows and columns must be positive numbers.");
            return;
        }

        new Psoriasis(rows, cols);
    }
    catch(NumberFormatException e) {
        showErrorAndExit(
            "Error: Please enter valid whole numbers.");
    }
    }

    private static void showErrorAndExit(String message)
    {
        JFrame errorFrame = new JFrame("Input Error");
        errorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    JPanel canvas = new JPanel() {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.RED);
            g.drawString(message, 20, 40);
        }
    };

    canvas.setPreferredSize(new Dimension(450, 80));
    errorFrame.add(canvas);
    errorFrame.pack();
    errorFrame.setLocationRelativeTo(null);
     errorFrame.setVisible(true);
        }

    /**
     * Run the automaton for one step.
     */
    public void step()
    {
        int numRows = cells.length;
        int numCols = cells[0].length;
        // Build a record of the next state of each cell.
        int[][] nextStates = new int[numRows][numCols];
        // Ask each cell to determine its next state.
        for(int row = 0; row < numRows; row++) {
            int[] rowOfStates = nextStates[row];
            for(int col = 0; col < numCols; col++) {
                rowOfStates[col] = cells[row][col].getNextState();
            }
        }
        // Update the cells' states.
        for(int row = 0; row < numRows; row++) {
            int[] rowOfStates = nextStates[row];
            for(int col = 0; col < numCols; col++) {
                setCellState(row, col, rowOfStates[col]);
            }
        }
        
        for(int row = 0; row < numRows; row++) {
            int[] rowOfStates = nextStates[row];
        for(int col = 0; col < numCols; col++) {
                setCellState(row, col, rowOfStates[col]);
        }
        }
        stepCount++;
        ratioHistory.add(getHealthyToSpreadRatio());
    }
    
    /**
     * Reset the state of the automaton to all Spread.
     */
    public void reset()
    {
        int numRows = cells.length;
        int numCols = cells[0].length;
        for(int row = 0; row < numRows; row++) {
            for(int col = 0; col < numCols; col++) {
                setCellState(row, col, Cell.Healthy);
            }
        }
    }
    
    /**
     * Generate a random setup.
     */
    public void randomize() 
    { int numRows = cells.length; 
        int numCols = cells[0].length;
        SecureRandom rand = new SecureRandom();
        for(int row = 0; row < numRows; row++) 
        { for(int col = 0; col < numCols; col++)
            { int randomNumber = rand.nextInt(100);
                if(randomNumber < 80) 
                { setCellState(row, col, Cell.Healthy); }
                else if(randomNumber < 90) 
                { setCellState(row, col, Cell.Spreading); }
                else { setCellState(row, col, Cell.Spread); } } } }
    
    /**
     * Set the state of one cell.
     * @param row The cell's row.
     * @param col The cell's col.
     * @param state The cell's state.
     */
    public void setCellState(int row, int col, int state)
    {
        cells[row][col].setState(state);
    }
    
    /**
     * Return the grid of cells.
     * @return The grid of cells.
     */
    public Cell[][] getCells()
    {
        return cells;
    }
    
    /**
     * Setup a new environment of the given size.
     * @param numRows The number of rows.
     * @param numCols The number of cols;
     */
    private void setup(int numRows, int numCols)
    {
        cells = new Cell[numRows][numCols];
        for(int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                cells[row][col] = new Cell();
            }
        }
        setupNeighbors();
    }
    
    /**
     * Give to a cell a list of its neighbors.
     */
    private void setupNeighbors()
    {
        int numRows = cells.length;
        int numCols = cells[0].length;
        // Allow for 8 neighbors plus the cell.
        ArrayList<Cell> neighbors = new ArrayList<>(9);
        for(int row = 0; row < numRows; row++) {
            for(int col = 0; col < numCols; col++) {
                Cell cell = cells[row][col];
                // This process will also include the cell.
                for(int dr = -1; dr <= 1; dr++) {
                    for(int dc = -1; dc <= 1; dc++) {
                        int nr = (numRows + row + dr) % numRows;
                        int nc = (numCols + col + dc) % numCols;
                        neighbors.add(cells[nr][nc]);
                    }
                }
                // The neighbours should not include the cell at
                // (row,col) so remove it.
                neighbors.remove(cell);
                cell.setNeighbors(neighbors);
                neighbors.clear();
            }
        }
    }
    
    public double getHealthyToSpreadRatio()
    {
    int healthy = 0;
    int spread = 0;

    for(int row = 0; row < cells.length; row++) {
        for(int col = 0; col < cells[row].length; col++) {

            if(cells[row][col].getState() == Cell.Healthy) {
                healthy++;
            }
            else if(cells[row][col].getState() == Cell.Spread) {
                spread++;
            }
        }
    }

    if(spread == 0) {
        return Double.NaN;
    }

        return (double) healthy / spread;
    }

    /**
     * Return the history of Healthy-to-Spread ratios.
     */
    public ArrayList<Double> getRatioHistory()
    {
    return ratioHistory;
    }
}
