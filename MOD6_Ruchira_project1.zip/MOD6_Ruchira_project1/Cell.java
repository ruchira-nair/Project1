
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A cell in a 2D cellular automaton. The cell has multiple possible states.
 * This is an implementation of the rules for scalp
 * 
 * @ruchira
 * @9/21
 */
public class Cell
{
    // The possible states.
    public static final int Healthy = 0, Spread = 1, Spreading = 2;
    // The number of possible states.
    public static final int NUM_STATES = 3;

    // The cell's state.
    private int state;
    // The cell's neighbors.
    private Cell[] neighbors;

    /**
     * Set the initial state to be Spread.
     */
    public Cell()
    {
        this(Healthy);
    }
    
    /**
     * Set the initial state.
     * @param initialState The initial state
     */
    public Cell(int initialState)
    {
        state = initialState;
        neighbors = new Cell[1];
    }
    
    /**
     * Determine this cell's next state, based on the state of its neighbors.
     * This is an implementation of the rules for Brian's Brain.
     * @return The next state.
     */
    public int getNextState()
    {
        if(state == Spread) {
            // Count the number of neighbors that are alive.
            long aliveCount = Arrays.stream(neighbors)
                                    .filter(n -> n.getState() == Healthy)
                                    .count();
            return aliveCount == 2 ? Healthy : Spread;
        }
        else if(state == Spreading) {
            return Spread;
        }
        else {
            return Spreading;
        }
    }
    
    /**
     * Receive the list of neighboring cells and take a copy.
     * @param neighborList Neighboring cells.
     */
    public void setNeighbors(ArrayList<Cell> neighborList)
    {
        neighbors = neighborList.toArray(new Cell[0]);
    }

    /**
     * Get the state of this cell.
     * @return The state.
     */
    public int getState()
    {
        return state;
    }
    
    /**
     * Set the state of this cell.
     * @param The state.
     */
    public void setState(int state)
    {
        this.state = state;
    }
}
